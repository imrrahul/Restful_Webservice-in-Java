package com.rahul.javabrains;

public class MyResource {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
